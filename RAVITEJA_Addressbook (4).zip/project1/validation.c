#include "addressbook.h"

int valid_num(struct AddressBook *addressBook,int count)
{
    int c= addressBook->contactCount;
        int print=1;
        
        // checks wheather the numbers are strating b/w 6-9
        if(addressBook->contacts[count].phone[0]>='6' && addressBook->contacts[count].phone[0]<='9')
        {
         print=2;

         // checks wheather the mobile contains exacte 10 numbers 
          if(strlen(addressBook->contacts[count].phone)==10)
          {
             print=3;
             // checks wheather the mobile numbers are numerical characters
               char*ptr = addressBook->contacts[count].phone;
               while(*ptr!= '\0')
              {
                if(!isdigit((unsigned char)*ptr))
                {
                  printf("\n!Please only enter numbers\n");
                  return 0;
                }
                  ptr++;

              }

             // checks duplicte numbers 
               for(int i=0;i<c;i++)
               {  
                  if(count!=i)
                  {
                    if(strcmp(addressBook->contacts[count].phone,addressBook->contacts[i].phone)==0)
                    {
                       printf("\n!The entered number is already exist,try diffrent number\n");
                       return 0;
                    }
                  }
               }
            
                 return 1;
          }
             
        }

        //Erorr messages

         if(print==1)
        {
            printf("\n!The number should be started from 6 to 9 only\n");
            return 0;
        }
        else if(print==2)
        {
            printf("\n!Entered number should be max 10 numbers\n");
            return 0;
        }
}


int valid_email(struct AddressBook *addressBook,int count)
{
    int c = addressBook->contactCount;
    //checks wheather atlest one character is present brfore '@'
    if(addressBook->contacts[count].email[0]=='@')
    {
         printf("\n!Invalid mail-id,Enter the correct email-address\n");
         return 0 ;
    }
    //checks wheather the substring '@gmail.com' is entered correct or not
    else if(strstr(addressBook->contacts[count].email,"@gmail.com")==NULL)
    {
        printf("\n!Invalid mail-id,Enter the correct email-address\n");
        return 0 ;
    }
    else
    {
       // checks duplicte email  
         for(int i=0;i<c;i++)
         {  if(count!=i)
            {
              if(strcmp(addressBook->contacts[count].email,addressBook->contacts[i].email)==0)
              {
                printf("\n!The entered mail-id is already exist,try diffrent mail-id\n");
                return 0;
              }
            }
         }

              //Checks wheather the space present in the mail-address
               char*ptr = addressBook->contacts[count].email;
               while(*ptr!= '\0')
              {
                if(*ptr==' ')
                {
                  printf("\n!Invalid mail-id,Enter the correct email-address\n");
                  return 0;
                }
                  ptr++;

              }
    }

    return 1;
}

int svalid_num(char *num)
{
        int print=1;
        
        // checks wheather the numbers are strating b/w 6-9
        if(num[0]>='6' && num[0]<='9')
        {
         print=2;

         // checks wheather the mobile contains exacte 10 numbers 
              if(strlen(num)==10)
              {
               print=3;

               // checks wheather the mobile numbers are numerical characters
                    char*ptr = num;
                    while(*ptr!= '\0')
                   {
                     if(!isdigit((unsigned char)*ptr))
                     {
                       printf("\n!Please only enter numbers\n");
                       return 0;
                     }
                     ptr++;

                    }
                    return 1;
              }
        }

        //Erorr messages

         if(print==1)
        {
            printf("\n!The number should be started from 6 to 9 only\n");
            return 0;
        }
        else if(print==2)
        {
            printf("\n!Entered number should be max 10 numbers\n");
            return 0;
        }
}

int svalid_email(char *mail)
{
    //checks wheather atlest one character is present brfore '@'
    if(mail[0]=='@')
    {
         printf("\n!Invalid mail-id,Enter the correct email-address\n");
         return 0 ;
    }
    //checks wheather the substring '@gmail.com' is entered correct or not
    else if(strstr(mail,"@gmail.com")==NULL)
    {
        printf("\n!Invalid mail-id,Enter the correct email-address\n");
        return 0 ;
    }
    //Checks wheather the space present in the mail-address
    else
    {
        
         char*ptr = mail;
         while(*ptr!= '\0')
         {
            if(*ptr==' ')
            {
                printf("\n!Invalid mail-id,Enter the correct email-address\n");
                return 0;
            }
            ptr++;

          }
    }
    return 1;

}




