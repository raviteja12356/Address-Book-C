#include "addressbook.h"

void add_contact(struct AddressBook *addressBook)
{   
      int count= addressBook->contactCount;
      
      //name part 
      printf("Enter the name:");
      scanf(" %[^\n]",addressBook->contacts[count].name);
      
      
      //phone number part  
      int ret;
            do
            {
              printf("Enter mobile number:");
              scanf(" %s",addressBook->contacts[count].phone);
              ret =  valid_num(addressBook,count);//calling function for validation of number 
            }while(ret==0);        
  
      //email part
      int re;
      do
      {
        printf("Enter the email-id:");
        scanf(" %[^\n]",addressBook->contacts[count].email);
        re=valid_email(addressBook,count);//calling function for validation of email
      }while(re==0); 

      // after creating/adding contact ,contact count will be increased by '+1'
      addressBook->contactCount++;
     

}

int search_contact(struct AddressBook *addressBook)
{
    int count = addressBook->contactCount,n=-1,not=3;

    //options to search cntacts
    printf("\n1.Search by name\n");
    printf("2.Search by number\n");
    printf("3.Search by email-address\n");
    
    do
    { 
      if(n==0 || n>3)
      {
        printf("Invalid choice!,enter the choice b/w 1-3\n");
      }
      printf("Select your choice: ");
      scanf("%d",&n);
    }while(n==0 || n>3);
    
    //Logic for search by name
    if(n==1)
    {
        char name[20];
        int n=1,p=0;
        printf("\nEnter the name: ");
        scanf(" %[^\n]",name);
        addressBook->ir_size=0;
       
        for(int i=0;i<count;i++)
        {
            if(strcmp(name,addressBook->contacts[i].name)==0)
           {
                not=7; 
                if(p==0)
                {
                   printf("\n-----Contact details-----\n");
                }
                printf("\n%d] %s %s %s\n",n++,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);      
                
                //after finding the contact the index number of the contact is stored in the index record array
                addressBook->index_record[addressBook->ir_size] = i;
                addressBook->ir_size++;
                p=1;
           }
        }
        if(not==3)
        {
        printf("\nContact not found X\n");
        return 0;
        }
        return 1;
      
    }

    //Logic for search by number
    else if(n==2)
    {
          char num[10];
          int n=1,p=0,ret;
    
            do
            {
              printf("Enter mobile number:");
              scanf(" %s",num);
              ret =  svalid_num(num);//calling function for validation of number while searching
            }while(ret==0);  
         addressBook->ir_size=0;
        
        for(int i=0;i<count;i++)
        {
            if(strcmp(num,addressBook->contacts[i].phone)==0)
           {
                 not=7;
                 if(p==0)
                {
                   printf("\n-----Contact details-----\n");
                }
                printf("%d] %s %s %s\n",n++,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);   
               
                //after finding the contact the index number of the contact is stored in the index record array
                addressBook->index_record[addressBook->ir_size] = i;
                addressBook->ir_size++;
                p=1;   
           }
        }
        if(not==3)
        {
         printf("\nContact not found X\n");
         return 0;
        }
       return 1;
    }

    //Logic for search by email-id
    else if(n==3)
    {
        char email[30];
        int n=1,p=0,re;

      do
      {
        printf("Enter the email-id:");
        scanf(" %[^\n]",email);
        re = svalid_email(email);//calling function for validation of email  while searching
      }while(re==0); 

        addressBook->ir_size=0;
        for(int i=0;i<count;i++)
        {
            if(strcmp(email,addressBook->contacts[i].email)==0)
           {
                not=7;
                if(p==0)
                {
                  printf("\n-----Contact details-----\n");
                }
                printf("%d] %s %s %s\n",n++,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);  
               
                //after finding the contact the index number of the contact is stored in the index record array
                addressBook->index_record[addressBook->ir_size] = i;
                addressBook->ir_size++;
                p=1;    

           }
        }
        if(not==3)
        {
          printf("\nContact not found X\n");
          return 0;
        }
        return 1;
    }

}

void edit_contact(struct AddressBook *addressBook)
{
     int r=search_contact(addressBook);
     if(r==0)
     {
      return;
     }
     int indx=-1,in=addressBook->ir_size;
     do
     {
       if(indx>in || indx==0)
       {
         printf("!Enter the correct contact number\n");
       }
       printf("Enter the contact number to edit: ");
       scanf("%d",&indx);
     }while(indx>in || indx==0);

     indx=indx-1;
     int i=addressBook->index_record[indx];
    
     int cho=-1;
     printf("\n1.Edit name\n2.Edit number\n3.Edit email-id\n4.Edit entire contact\n");
     do
     {
      if(cho==0 ||cho>4 )
      {
        printf("Invalid choice!,enter the choice b/w 1-4\n");
      }
     printf("Enter the choice: ");
     scanf("%d",&cho);
     }while(cho==0 || cho>4);

   switch(cho)
   {
      //edit only name part 
      case 1:
      printf("Enter the name:");
      scanf(" %[^\n]",addressBook->contacts[i].name);
      printf("\nContact successfully edited...\n");
      break;
      
      //edit only phone number part  
      case 2:
      int ret;
            do
            {
              printf("Enter mobile number:");
              scanf(" %s",addressBook->contacts[i].phone);
              ret =  valid_num(addressBook,i);
            }while(ret==0);  
       printf("\nContact successfully edited...\n");         
      break;
  
       //edit only email
      case 3:
      int re;
      do
      {
        printf("Enter the email-id:");
        scanf(" %[^\n]",addressBook->contacts[i].email);
        re=valid_email(addressBook,i);
      }while(re==0);
      printf("\nContact successfully edited...\n");
      break;

      //edit entire contact
      case 4:
      int count= addressBook->contactCount;
      
      //name part 
      printf("Enter the name:");
      scanf(" %[^\n]",addressBook->contacts[i].name);
      
      
      //phone number part  
      int r;
            do
            {
              printf("Enter mobile number:");
              scanf(" %s",addressBook->contacts[i].phone);
              r=  valid_num(addressBook,i);
            }while(r==0);        
  
      //email part
      int r1;
      do
      {
        printf("Enter the email-id:");
        scanf(" %[^\n]",addressBook->contacts[i].email);
        r1=valid_email(addressBook,i);
      }while(r1==0); 

      printf("\nContact successfully edited...\n");

   }
}

void delete_contact(struct AddressBook *addressBook)
{
  int r=search_contact(addressBook);
  if(r==0)
  {
    return;
  }
  int indx=-1,in=addressBook->ir_size;
     do
     {
       if(indx>in || indx==0)
       {
         printf("!Enter the correct contact number\n");//error message
       }
       printf("Enter the contact number to delete: ");
       scanf("%d",&indx);
     }while(indx>in || indx==0);
     indx=indx-1;
     int j=addressBook->index_record[indx];
    
     int del=-1,count=addressBook->contactCount;
     //conformation massage befor deleting
     printf("\nAre you sure !?,Once you delete the contact it will be deleted permanentlly\nIf 'YES' enter '1'\nIf 'NOT' enter '2'\n");//conforming befor deleting

      do
      {
        if(del>2 || del==0)
        {
           printf("\n!Enter the correct choice,that is '1'(Delete & exit) (or) '2'(Exit without deleting)\n");
        }
        printf("Enter your choice: ");
        scanf("%d",&del);
      }while(del>2 || del==0);
      
      //Deleting the message logic
      if(del==1)
      {
        
         for(int i=j;i<count-1;i++)
         {
            addressBook->contacts[i]=addressBook->contacts[i+1];
         }
         addressBook->contactCount--;
         printf("\n*****Contact deleted successfully*****\n");
      }
      //Without deleting we are returning
      else
      {
        printf("\nExiting without deleting.......\n");
        return;
      }
     

}

void list_contacts(struct AddressBook *addressBook)
{
    int count= addressBook->contactCount;
    int num=0;

    //Logic to list the entire contact in order
    do
    {
        printf("...................................................................\n");
        printf("%-5.5s%-15.4s%-13.8s%8.6s","SNo","Name","Mob.Number","Email");
        printf("\n...................................................................\n");
        for(int i=0;i<count;i++)
        {
            printf("%-5.0d%-15.15s%-16.10s%-10.30s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        }
        printf("...................................................................\n");
        printf("Total contacts %d \n",addressBook->contactCount);
        printf("...................................................................\n");
        printf("Enter 1 to exit : ");
        scanf("%d",&num);
    }while(num!=1);
}

void save_contacts(struct AddressBook *addressBook)
{
   //Logic for save the contacts for structure to the file 
    FILE *fp;
    fp=fopen("database.csv","w");
    if(fp==NULL)
    {
    perror("ERROR");
    return;
    }

    for(int i=0;i<addressBook->contactCount;i++)
    {
        fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    fclose(fp);
}

void acces_contacts(struct AddressBook *addressBook)
{ 
    //Logic for reloading the contacts details for file to the structure 
    int count=addressBook->contactCount;
    FILE *fp;
    fp=fopen("database.csv","r");
    if(fp==NULL)
    {
    perror("ERROR");
    return ;
    }
    
    while(fscanf(fp,"%[^,],%[^,],%[^\n]\n",addressBook->contacts[count].name,addressBook->contacts[count].phone,addressBook->contacts[count].email)!=EOF)
    {
        addressBook->contactCount++;
        count++;
    }
        
    fclose(fp);
}

