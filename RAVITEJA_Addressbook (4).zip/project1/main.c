#include "addressbook.h"
/*
NAME : K RAVITEJA
DATE : 03/04/2026

DISCRIPTION :This project is a menu-driven Address Book Management System developed using the C programming language.
 It allows users to store, manage, and manipulate contact details efficiently. 
 The system supports essential operations such as adding new contacts, searching existing contacts, 
 editing details, deleting contacts, and displaying all saved contacts. 
 
 This project is useful for understanding fundamental programming concepts 
and real-world application development in C. It demonstrates how data can be organized 
and managed efficiently in a structured format. Practically, it can serve as a basic contact management tool. 

*/

int main() 
{
    int choice;

    struct AddressBook addressBook;
    addressBook.contactCount = 0;
    addressBook.ir_size = 0;
    acces_contacts(&addressBook);
    printf("%zu\n", sizeof(addressBook));
    
    do 
    {
	printf("\nAddress Book Menu:\n");
	printf("1. Add/Create contact\n");
	printf("2. Search contact\n");
	printf("3. Edit contact\n");
	printf("4. Delete contact\n");
	printf("5. List all contacts\n");
	printf("6. Save & Exit\n");
	printf("Enter your choice: ");

	scanf("%d", &choice);

	switch (choice) 
	{
	    case 1:
		add_contact(&addressBook);
		break;
	    case 2:
		search_contact(&addressBook);
		break;
	    case 3:
		edit_contact(&addressBook);
		break;
	    case 4:
		delete_contact(&addressBook);
		break;
	    case 5:
		list_contacts(&addressBook);
		break;
	    case 6:
		save_contacts(&addressBook);
		printf("Saving and Exiting...\n");
		break;
	    default:
		printf("Invalid choice. Please try again.\n");
	}
    } while (choice != 6);

    return 0;
}
