#ifndef CONTACT_H
#define CONTACT_H
#include<stdio.h>
#include<string.h>
#include<ctype.h>


struct Contact{
    char name[50];
    char phone[15];
    char email[50];
};

struct AddressBook {
    struct Contact contacts[100];
    int contactCount;
    int index_record[100];
    int ir_size;
};

//Basic functions of addressbook
void add_contact(struct AddressBook *addressBook);
int search_contact(struct AddressBook *addressBook);
void edit_contact(struct AddressBook *addressBook);
void delete_contact(struct AddressBook *addressBook);
void list_contacts(struct AddressBook *addressBook);

//Validation Functions
int valid_num(struct AddressBook *addressBook,int count);
int valid_email(struct AddressBook *addressBook,int count);
int svalid_num(char *num);
int svalid_email(char *mail);

//functions used to save the contacts details from structure to file and access contacts form file to structure
void save_contacts(struct AddressBook *addressBook);
void acces_contacts(struct AddressBook *addressBook);

#endif
 